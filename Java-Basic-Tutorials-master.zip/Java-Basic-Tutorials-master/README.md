# Java-Basic-Tutorials
This is for those who come from my Java Basic Tutorials 
